document.getElementById("upImg").addEventListener("click", function(){
    document.getElementById("center").style.top = "100px";
});

document.getElementById("down").addEventListener("click", function(){
    document.getElementById("center").style.top = "300px";
});

document.getElementById("left").addEventListener("click", function(){
    document.getElementById("center").style.left = "700px";
});

document.getElementById("right").addEventListener("click", function(){
    document.getElementById("center").style.left = "900px";
});
